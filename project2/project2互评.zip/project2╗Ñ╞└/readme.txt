The whole file folder contains a isredblacktree.c file(contains the source code and necessary comments)
                              a isredblacktree.exe file(executable file)
                              a project2report.pdf(systematically describes and analysizes the whole project)
                              a traindata.txt file(contains some samples for you to test)
                              a readme.txt(help you to smoothly run and test my project)

You can open the isredblacktree.c by devc++ or Vscode and then run the program.

You need to input some numbers! You can test whatever you would like to test or copy part of data from the traindata txt.

You will get Yes or No as the result.

Hope you a nice day!