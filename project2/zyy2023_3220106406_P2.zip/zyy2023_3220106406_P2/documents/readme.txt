The whole file folder contains a 'code' file folder and a 'documents' file folder.
In the 'code' file folder,there is a c file(contains the source code and necessary comments)
                                   an executable file(in case that my code cannot be compiled by you)
In the 'documents' file folder,there is a pdf(which is my report of this project,systematically describing and analysizing the whole project)
                                        a readme.txt(help you to quickly understand what you can do so that you can smoothly run and test my project)

You can open the isredblacktree.c by devc++ or Vscode and then run the program.

You need to input some numbers! You can test whatever you would like to test or copy part of data from the following data I provide for you.

You will get Yes or No as the result.

Hope you a nice day!



Here's some data provided for you.

traindata 1:
3
9
7 -2 1 5 -4 -11 8 14 -15
9
11 -2 1 -7 5 -4 8 14 -15
8
10 -7 5 -6 8 15 -11 17
result:
Yes
No
No

traindata2:
1
0
result:
Yes

traindata3
1
8
5 1 -1 3 9 7 8 11
result:
No