The whole file folder contains a 'code' file folder and a 'documents' file folder.
In the 'code' file folder,there is a c file(contains the source code and necessary comments)
                                 note:so there is no executable file because the it can't be uploaded 
In the 'documents' file folder,there is a pdf(which is my report of this project,systematically describing and analysizing the whole project)
                                        a readme.txt(help you to quickly understand what you can do so that you can smoothly run and test my project)

You can open the project3.c by any IDE and then run the program.

You need to input some numbers! You can test whatever you would like to test or copy part of data from the following data I provide for you.

You will get Yes or No as the result.

Hope you a nice day!



Here's some data provided for you.

5 7
1 2 2
1 5 1
2 3 1
2 4 1
2 5 2
3 5 1
3 4 1
4
5 1 3 4 2
5 3 1 2 4
2 3 4 5 1
3 2 1 5 4

the correct results is:
Yes
Yes
Yes
No